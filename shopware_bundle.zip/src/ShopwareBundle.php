<?php
namespace shopware_bundle\ShopwareBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopwareBundle extends Bundle
{
    
}